# Oryn Registry runtime dependency

This versioned package supplies compiled JavaScript, declarations, schemas and the bundled model catalog used by Oryn Browser. Its original code and data are MIT licensed; see LICENSE. Registry source and deployment tooling are maintained separately and are not included in this source distribution.
