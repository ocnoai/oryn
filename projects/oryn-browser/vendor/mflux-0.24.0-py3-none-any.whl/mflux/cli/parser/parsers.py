import argparse
import json
import math
import random
import sys
import time
import typing as t
import warnings
from pathlib import Path

from mflux.cli.defaults import defaults as ui_defaults
from mflux.models.common.compute_precision import ComputePrecision
from mflux.models.common.resolution.config_resolution import ConfigResolution
from mflux.models.common.resolution.lora_resolution import LoraResolution
from mflux.models.common.schedulers import SCHEDULER_REGISTRY
from mflux.models.flux.variants.in_context.utils.in_context_loras import LORA_NAME_MAP
from mflux.utils import box_values, scale_factor
from mflux.utils.logging_util import LoggingUtil


def finite_float(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed):
        raise argparse.ArgumentTypeError(f"expected a finite number, got {value!r}")
    return parsed


class ModelSpecAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, values)


def int_or_special_value(value) -> int | scale_factor.ScaleFactor:
    if value.lower() == "auto":
        return scale_factor.ScaleFactor(value=1)

    # Try to parse as integer first
    try:
        return int(value)
    except ValueError:
        pass

    # If not an integer, try to parse as scale factor
    try:
        return scale_factor.ScaleFactor.parse(value)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"'{value}' is not a valid integer or 'auto' or a scale factor like '2x' or '3.5x'"
        )


def lora_init_kwargs_from_args(args: argparse.Namespace) -> dict[str, t.Any]:
    return {
        "lora_paths": args.lora_paths,
        "lora_scales": args.lora_scales,
        "bake_lora": args.bake_lora,
    }


def positive_float(value: str) -> float:
    try:
        parsed = float(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"'{value}' is not a valid number")
    if parsed <= 0:
        raise argparse.ArgumentTypeError(f"'{value}' must be > 0")
    return parsed


def open_unit_float(value: str) -> float:
    try:
        parsed = float(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"'{value}' is not a valid number")
    if not 0 < parsed < 1:
        raise argparse.ArgumentTypeError(f"'{value}' must be > 0 and < 1")
    return parsed


def positive_fraction(value: str) -> float:
    # A share that may be all of it: --cfg-end 1 runs CFG on every step
    try:
        parsed = float(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"'{value}' is not a valid number")
    if not 0 < parsed <= 1:
        raise argparse.ArgumentTypeError(f"'{value}' must be > 0 and <= 1")
    return parsed


def vae_tile_size(value: str) -> int:
    # The decode tiler uses a fixed 64px overlap; the tile must be strictly larger
    # than the overlap or the tiling stride becomes <= 0. 128 is the practical floor.
    try:
        parsed = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"'{value}' is not a valid integer")
    if parsed < 128:
        raise argparse.ArgumentTypeError(f"'{value}' is too small: minimum tile size is 128 (tiles overlap by 64px)")
    if parsed % 16 != 0:
        raise argparse.ArgumentTypeError(f"'{value}' must be a multiple of 16")
    return parsed


# fmt: off
class CommandLineParser(argparse.ArgumentParser):

    def __init__(self, *args, **kwargs):
        # Abbreviated long options (argparse's prefix matching) are rejected: option
        # provision is detected by scanning argv (_option_was_provided), which cannot see
        # abbreviations, and an abbreviation that is unambiguous today silently breaks
        # the moment a new option shares its prefix.
        kwargs.setdefault("allow_abbrev", False)
        super().__init__(*args, **kwargs)
        self.supports_metadata_config = False
        self.supports_image_generation = False
        self.supports_controlnet = False
        self.supports_dimension_scale_factor = False
        self.supports_image_to_image = False
        self.supports_image_outpaint = False
        self.supports_lora = False
        self.require_model_arg = True
        self.require_init_image = False
        self.require_image_paths = False
        self.require_redux_image_paths = False
        self.default_model = None
        self.add_argument("--verbose", "-v", action="store_true", default=False, help="Enable verbose (debug-level) logging.")

    def add_general_arguments(self) -> None:
        self.add_argument("--battery-percentage-stop-limit", "-B", type=lambda v: max(min(int(v), 99), 1), default=ui_defaults.BATTERY_PERCENTAGE_STOP_LIMIT, help=f"On Macs powered by battery, stop image generation when battery reaches this percentage. Default: {ui_defaults.BATTERY_PERCENTAGE_STOP_LIMIT}")
        self.add_argument("--low-ram", action="store_true", help="Enable low-RAM mode to reduce memory usage (may impact performance).")
        self.add_argument("--mlx-cache-limit-gb", type=positive_float, default=None, help="Limit MLX cache size in GB without enabling full low-RAM mode (e.g. 8 or 16).")
        self.add_argument("--vae-tiling", action="store_true", help="Decode the image in overlapping tiles to reduce peak memory during the VAE decode phase, without enabling full low-RAM mode. Implied by --low-ram.")
        self.add_argument("--vae-tile-size", type=vae_tile_size, default=None, help="Tile size in pixels for tiled VAE decoding (default: 512, minimum: 128, multiple of 16). Smaller tiles (e.g. 256) further reduce peak memory. Implies --vae-tiling.")

    def add_seedvr2_upscale_arguments(self) -> None:
        self.supports_image_generation = True
        self.require_prompt = False
        seedvr2_group = self.add_argument_group("SeedVR2 upscale configuration")
        seedvr2_group.add_argument(
            "--image-path",
            "-i",
            type=Path,
            required=True,
            nargs="+",
            help="Path to the input image(s) or directories to upscale.",
        )
        seedvr2_group.add_argument("--seed", "-s", type=int, default=[42], nargs="+", help="Random seed(s) for reproducibility.")
        seedvr2_group.add_argument("--resolution", "-r", type=int_or_special_value, default=384, help="Target resolution for the shortest edge (pixels) or scale factor (e.g., '2x').")
        seedvr2_group.add_argument("--softness", type=float, default=0.0, help="Value between 0.0 (off, factor 1) and 1.0 (max, factor 8). Default: 0.0.")

    def add_model_arguments(self, path_type: t.Literal["load", "save"] = "load", require_model_arg: bool = True, default_model: str | None = None) -> None:
        # `default_model` is the model this CLI runs when --model is omitted. It is only
        # read to resolve defaults that depend on the model (--steps); it is deliberately
        # NOT written to namespace.model, which stays None so the metadata-config restore
        # and the model_path computation below keep their "user named nothing" signal.
        self.require_model_arg = require_model_arg
        self.default_model = default_model
        self.add_argument("--model", "-m", type=str, required=require_model_arg, action=ModelSpecAction, help=f"The model to use: a built-in model name ({', '.join(ui_defaults.canonical_model_choices())}) or any of its aliases, a HuggingFace repo org/model, or a local path.")
        if path_type == "save":
            # Not required here: mflux-save picks a folder in $MFLUX_MODELS_DIR when --path is missing.
            self.add_argument("--path", type=str, default=None, help="Local folder to save the model to. If you do not give it, mflux saves to $MFLUX_MODELS_DIR/<name>-mflux-<qN|bf16|fp8>[-loraNN].")
        # No argparse choices= here: the accepted values are whatever ConfigResolution's
        # explicit-base rule accepts, and they are validated post-parse (see parse_args) so
        # the two can never drift apart again, and so values restored from a metadata
        # sidecar are checked by the same rule as values typed on the command line.
        self.add_argument("--base-model", type=str, required=False, metavar="MODEL", help="When using a third-party HuggingFace model or local path, explicitly name the built-in model it is based on (e.g. dev, schnell, qwen-image).")
        self.add_argument("--quantize",  "-q", type=int, choices=ui_defaults.QUANTIZE_CHOICES, default=None, help=f"Quantize the model ({' or '.join(map(str, ui_defaults.QUANTIZE_CHOICES))}, Default is None)")

    def add_compute_precision_arguments(self) -> None:
        self.add_argument("--compute-precision", type=str, choices=sorted(ComputePrecision.CHOICES), default=None, help="Run the inside of the attention and feed-forward layers in this precision; the residual stream, norms, text encoder and VAE keep the model's own. float16 helps most on GPUs with slow bfloat16 (Apple M1 and M2); the gain is small or zero on M4 and M5. The image changes slightly for the same seed. Default: off.")

    def add_lora_arguments(self, bake_by_default: bool = True) -> None:
        # bake_by_default is off for a model whose LoRAs lose part of their update in a merge (MOSS-Image).
        self.supports_lora = True
        lora_group = self.add_argument_group("LoRA configuration")
        lora_group.add_argument("--lora-style", type=str, choices=sorted(LORA_NAME_MAP.keys()), help="Style of the LoRA to use (e.g., 'storyboard' for film storyboard style)")
        lora_group.add_argument("--lora", dest="lora", action="append", nargs="+", default=None, metavar=("PATH", "SCALE"), help="Add a LoRA as an atomic PATH with optional SCALE (default 1.0). Repeatable: --lora A.safetensors 0.7 --lora B.safetensors. PATH accepts local files, HuggingFace repos (org/model), or collection format (repo:filename.safetensors). Preferred over --lora-paths/--lora-scales.")
        self.add_argument("--lora-paths", type=str, nargs="*", default=None, help="[DEPRECATED: use --lora] LoRA paths: local files, HuggingFace repos (org/model), or collection format (repo:filename.safetensors). Pass it with no values to run without the LoRAs a --config-from-conf sidecar would otherwise restore.")
        self.add_argument("--lora-scales", type=float, nargs="*", default=None, help="[DEPRECATED: use --lora] Scaling factor to adjust the impact of LoRA weights on the model. A value of 1.0 applies the LoRA weights as they are.")
        bake_help = "(default: on). Use --no-bake-lora to keep runtime adapters." if bake_by_default else "(default: off). Without it, the adapters stay runtime layers and apply all of their update."
        lora_group.add_argument(
            "--bake-lora",
            action=argparse.BooleanOptionalAction,
            default=bake_by_default,
            help=f"Merge LoRA/LoKr deltas into base weights after load {bake_help}",
        )

    def _add_image_generator_common_arguments(self, supports_dimension_scale_factor=False) -> None:
        self.supports_image_generation = True
        if supports_dimension_scale_factor:
            self.supports_dimension_scale_factor = True
            self.add_argument("--height", type=int_or_special_value, default="auto", help="Image height (Default is source image height)")
            self.add_argument("--width", type=int_or_special_value, default="auto", help="Image width (Default is source image width)")
        else:
            self.add_argument("--height", type=int, default=ui_defaults.HEIGHT, help=f"Image height (Default is {ui_defaults.HEIGHT})")
            self.add_argument("--width", type=int, default=ui_defaults.WIDTH, help=f"Image width (Default is {ui_defaults.WIDTH})")

        self.add_argument("--steps", type=int, default=None, help="Inference Steps")
        self.add_argument("--guidance", type=float, default=None, help=f"Guidance Scale (Default varies by tool: {ui_defaults.GUIDANCE_SCALE} for most, {ui_defaults.DEFAULT_DEV_FILL_GUIDANCE} for fill tools, {ui_defaults.DEFAULT_DEPTH_GUIDANCE} for depth)")

    def add_image_generator_arguments(self, supports_metadata_config=False, require_prompt=True, supports_dimension_scale_factor=False) -> None:
        # Kept on self so add_in_context_edit_arguments can put --instruction in the
        # same group: exclusivity declared here is what mflux-capabilities publishes.
        self._prompt_group = self.add_mutually_exclusive_group(required=(require_prompt and not supports_metadata_config))
        self._prompt_group.add_argument("--prompt", type=str, help="The textual description of the image to generate.")
        self._prompt_group.add_argument("--prompt-file", type=Path, help="Path to a file containing the prompt text. The file will be re-read before each generation, allowing you to edit the prompt between iterations when using multiple seeds without restarting the program.")
        self.add_argument("--negative-prompt", type=str, default="", help="The negative prompt to guide what the model should not generate.")
        self.add_argument("--seed", type=int, default=None, nargs='+', help="Specify 1+ Entropy Seeds (Default is 1 time-based random-seed)")
        self.add_argument("--auto-seeds", type=int, default=-1, help="Auto generate N Entropy Seeds (random ints between 0 and 1 billion")
        self.add_argument("--scheduler", type=str, default="linear", help="Choose from implemented schedulers (linear only for now). Or bring your own: 'your_package.some_module.FooScheduler'")
        self._add_image_generator_common_arguments(supports_dimension_scale_factor=supports_dimension_scale_factor)
        if supports_metadata_config:
            self.add_metadata_config()
        self.require_prompt = require_prompt

    def add_image_to_image_arguments(self, required=False) -> None:
        self.supports_image_to_image = True
        # The requirement is enforced after normalization (see parse_args) so it can be
        # satisfied by either the new --image flag or the legacy --image-path flag.
        self.require_init_image = required
        self.add_argument("--image", dest="image", nargs="+", default=None, metavar=("PATH", "STRENGTH"), help=f"Init image as an atomic PATH with optional STRENGTH (default {ui_defaults.IMAGE_STRENGTH}): --image photo.jpg 0.6. Preferred over --image-path/--image-strength.")
        self.add_argument("--image-path", type=Path, required=False, default=None, help="[DEPRECATED: use --image] Local path to init image")
        self.add_argument("--image-strength", type=float, required=False, default=ui_defaults.IMAGE_STRENGTH, help=f"[DEPRECATED: use --image] Controls how strongly the init image influences the output image. A value of 0.0 means no influence. (Default is {ui_defaults.IMAGE_STRENGTH})")

    def add_image_paths_arguments(self, required: bool = True) -> None:
        # The requirement is enforced after parsing (see parse_args) rather than by argparse:
        # argparse checks required= before parse_args reaches the metadata block, so an edit
        # CLI exited 2 on images a --config-from-metadata sidecar was carrying.
        self.require_image_paths = required
        self.add_argument("--image-paths", type=Path, nargs="+", default=None, help="Local paths to one or more init images. For single image editing, provide one path. For multiple image editing, provide multiple paths.")

    def add_batch_image_generator_arguments(self) -> None:
        self.add_argument("--batch-prompts-file", type=Path, required=True, default=argparse.SUPPRESS, help="Local path for a file that holds a batch of prompts.")
        self.add_argument("--global-seed", type=int, default=argparse.SUPPRESS, help="Entropy Seed (used for all prompts in the batch)")
        self._add_image_generator_common_arguments()

    def add_fill_arguments(self) -> None:
        self.add_argument("--image-path", type=Path, required=True, help="Local path to the source image")
        self.add_argument("--masked-image-path", type=Path, required=True, help="Local path to the mask image")

    def add_catvton_arguments(self) -> None:
        self.add_argument("--person-image", type=str, required=True, help="Path to person image")
        self.add_argument("--person-mask", type=str, required=True, help="Path to person mask image")
        self.add_argument("--garment-image", type=str, required=True, help="Garment Image")

    def add_in_context_edit_arguments(self) -> None:
        self.supports_in_context_edit = True
        self.add_argument("--reference-image", type=str, required=True, help="Path to reference image")
        # Joins the prompt/prompt-file group so argparse owns the exclusivity and the
        # capabilities dump shows it; "one of them is required" stays post-parse.
        self._prompt_group.add_argument("--instruction", type=str, help="User instruction to be wrapped in diptych template (e.g., 'make the hair black'). This will be automatically formatted as 'A diptych with two side-by-side images of the same scene. On the right, the scene is exactly the same as on the left but {instruction}'. Either --instruction or --prompt is required.")  # fmt:off

    def add_in_context_arguments(self) -> None:
        self.add_argument("--save-full-image", action="store_true", default=False, help="Additionally, save the full image containing the reference image. Useful for verifying the in-context usage of the reference image.")

    def add_in_context_dev_arguments(self) -> None:
        self.add_argument("--reference-image", type=Path, required=True, dest="image_path", help="Path to reference image")

    def add_depth_arguments(self) -> None:
        self.add_argument("--image-path", type=Path, required=False, help="Local path to the source image")
        self.add_argument("--depth-image-path", type=Path, required=False, help="Local path to the depth image")
        self.add_argument("--save-depth-map", action="store_true", required=False, help="If set, save the depth map created from the source image.")

    def add_save_depth_arguments(self) -> None:
        self.add_argument("--image-path", type=Path, required=True, help="Local path to the source image")
        self.add_argument("--quantize",  "-q", type=int, choices=ui_defaults.QUANTIZE_CHOICES, default=None, required=False, help=f"Quantize the model ({' or '.join(map(str, ui_defaults.QUANTIZE_CHOICES))}, Default is None)")

    def add_hf_symlink_argument(self) -> None:
        # const="" marks "flag given without a name", so the name comes from the environment or the OS.
        self.add_argument("--hf-symlink", type=str, nargs="?", const="", default=None, metavar="USERNAME", help="After the save, add a Hugging Face cache entry <USERNAME>/<folder name> that links to the saved files, so --model can load it by repo id. mflux copies no data. USERNAME order: this flag, then $MFLUX_HF_USERNAME, $HF_NAMESPACE, $HF_NAME, then the OS user name.")

    def add_redux_arguments(self) -> None:
        # Same post-parse requirement as --image-paths: argparse required= is checked
        # before the metadata block, so a redux sidecar could not be replayed with -C.
        self.require_redux_image_paths = True
        self.add_argument("--redux-image-paths", type=Path, nargs="*", default=None, help="Local path to the source image")
        self.add_argument("--redux-image-strengths", type=float, nargs="*", default=None, help="Strength values (between 0.0 and 1.0) for each reference image. Default is 1.0 for all images.")

    def add_step_cache_arguments(self) -> None:
        # --teacache-ratio is the flag's first released name (Qwen Image 2.1); it stays as an alias.
        self.add_argument("--step-cache-ratio", "--teacache-ratio", dest="step_cache_ratio", type=open_unit_float, default=None, help="TeaCache-style step reuse: skip the transformer on this fraction of denoise steps (those whose timestep signal changes least; the first and last 10%% always run) and reuse the previous step's prediction. Must be within (0, 1). Trades a little detail for speed: 0.25 is about 1.4x faster. Runs under 10 steps are unaffected. Default: off.")

    def add_cfg_end_arguments(self) -> None:
        # Ideogram 4's option (#441); the cutoff is mflux.models.common.cfg_end.CfgEnd
        self.add_argument("--cfg-end", type=positive_fraction, default=None, help="Fraction of steps (0-1) that run CFG; the remaining steps run cond-only (guidance 1.0, skipping the unconditional forward). Lower = faster. Default: full CFG.")

    def add_pid_decode_arguments(self) -> None:
        self.add_argument("--pid-decode", action=argparse.BooleanOptionalAction, default=False, help="Decode with NVIDIA PiD's pixel-diffusion super-resolving decoder instead of the standard VAE. First run downloads two separate Hugging Face checkpoints (~8GB total); google/gemma-2-2b-it is gated and requires accepting its license + `hf auth login`.")
        self.add_argument("--pid-degrade-sigma", type=float, default=0.0, help="With --pid-decode, deliberately noise the latent to this flow-matching sigma before decoding (0.0-0.8). PiD's LQ gate was distilled on latents noised at sigma~U[0.0, 0.8]; a fully clean latent (the default, sigma=0.0) is the input it saw least during training, which can show up as over-textured detail invented on smooth areas like skin. Try 0.2 if you see that. Ignored without --pid-decode.")

    def add_small_text_encoder_arguments(self, help_text: str | None = None) -> None:
        self.add_argument("--small-text-encoder", action=argparse.BooleanOptionalAction, default=False, help=help_text or "[EXPERIMENTAL] Replace klein-4B's Qwen3-4B text encoder with Qwen3-0.6B + the AiArtLab/qwen3-0.6b-4b-adapter (FLUX.2-klein-4B / klein-base-4B only). Needs 1-5.6 GB less memory for weights depending on -q and downloads ~2.3 GB instead of ~7.5 GB; prompts are capped at 256 tokens and fine details can drift from the native encoder.")

    def add_vae_full_precision_arguments(self) -> None:
        self.add_argument("--vae-full-precision", action=argparse.BooleanOptionalAction, default=False, help="Decode each VAE block on the full image in fp32, as the earlier decode did, not in bf16 row strips. The decode needs more memory (8.6 GB at 1024x1024, compared with 1.6 GB).")

    def add_small_decoder_arguments(self) -> None:
        self.add_argument("--small-decoder", action=argparse.BooleanOptionalAction, default=False, help="Decode with black-forest-labs/FLUX.2-small-decoder, a distilled VAE decoder with about half the parameters of the standard one. Decoding is faster and needs less memory; images are almost the same. First run downloads ~250 MB. Cannot be used with --pid-decode.")

    def add_float32_arguments(self) -> None:
        self.add_argument("--float32", action=argparse.BooleanOptionalAction, default=False, help="Run the transformer hidden stream in float32, as in mflux 0.20 and earlier. On an M5, the default bfloat16 stream is about 30%% faster. The two streams give slightly different images for the same seed. Use this flag to reproduce an image from an older release.")

    def add_output_arguments(self) -> None:
        # --metadata and --no-metadata are the first released names (#703). They stay as aliases.
        self.add_argument("--make-conf", "--metadata", dest="metadata", action="store_true", help="Write the generation parameters to a JSON sidecar (<output>.metadata.json). Use it again with --config-from-conf/-C.")
        self.add_argument("--no-exif", "--no-metadata", dest="no_metadata", action="store_true", help="Do not embed generation metadata (EXIF UserComment and friends) in the output image. Independent of --make-conf, which writes the JSON sidecar.")
        self.add_argument("--output", type=str, default="image.png", help="The filename for the output image. Default is \"image.png\".")
        self.add_argument('--stepwise-image-output-dir', type=str, default=None, help='[EXPERIMENTAL] Output dir to write step-wise images and their final composite image to. This feature may change in future versions.')

    def add_image_outpaint_arguments(self, required=False) -> None:
        self.supports_image_outpaint = True
        self.add_argument("--image-outpaint-padding", type=str, default=None, required=required, help="For outpainting mode: CSS-style box padding values to extend the canvas of image specified by--image-path. E.g. '20', '50%%'")

    def add_controlnet_arguments(self, mode: str | None = None, require_image=False) -> None:
        self.supports_controlnet = True
        self.add_argument("--controlnet-image-path", type=str, required=require_image, help="Local path of the image to use as input for controlnet.")
        self.add_argument("--controlnet-strength", type=float, default=ui_defaults.CONTROLNET_STRENGTH, help=f"Controls how strongly the control image influences the output image. A value of 0.0 means no influence. (Default is {ui_defaults.CONTROLNET_STRENGTH})")
        if mode == 'canny':
            self.add_argument("--controlnet-save-canny", action=argparse.BooleanOptionalAction, default=False, help="If set, save the Canny edge detection reference input image.")

    def add_union_controlnet_arguments(self, require_controls: bool = True) -> None:
        """
        Union-style ControlNet inputs (e.g. pose/depth/canny/hed/mlsd).\n
        Uses a repeatable `--control` argument with format: `type:path[:strength]`.
        """
        self.supports_controlnet = True
        self.add_argument(
            "--control",
            action="append",
            required=require_controls,
            help="Repeatable control spec: type:path[:strength] (e.g. pose:pose.png:0.8). The strength is the model card's control_context_scale; 0.65 to 1.0 is the recommended range, default 1.0.",
        )
        # 1.0, not the FLUX ControlNet's 0.4: the effective scale is this multiplier times the
        # per-control strength, and 0.4 x 0.85 = 0.34 sits below the range where the Union
        # ControlNet follows its hint at all (#721).
        self.add_argument(
            "--controlnet-strength",
            type=finite_float,
            default=ui_defaults.UNION_CONTROLNET_STRENGTH,
            help=f"Global multiplier applied to every control's strength. (Default is {ui_defaults.UNION_CONTROLNET_STRENGTH}, so each control's own strength is the effective scale)",
        )

    def add_concept_attention_arguments(self) -> None:
        concept_group = self.add_argument_group("Concept Attention configuration")
        concept_group.add_argument("--concept", type=str, required=True, help="The concept prompt to use for attention visualization")
        concept_group.add_argument("--input-image-path", type=Path, required=False, default=None, help="Local path to reference image for concept attention analysis (uses Flux1ConceptFromImage instead of text-based concept)")
        concept_group.add_argument("--heatmap-layer-indices", type=int, nargs="*", default=list(range(15, 19)), help="Layer indices to use for heatmap generation (default: 15-18)")
        concept_group.add_argument("--heatmap-timesteps", type=int, nargs="*", default=None, help="Timesteps to use for heatmap generation (default: all timesteps)")

    def add_concept_from_image_arguments(self) -> None:
        concept_group = self.add_argument_group("Concept Attention from Image configuration")
        concept_group.add_argument("--concept", type=str, required=True, help="The concept prompt to use for attention visualization")
        concept_group.add_argument("--input-image-path", type=Path, required=True, help="Local path to reference image for concept attention analysis")
        concept_group.add_argument("--heatmap-layer-indices", type=int, nargs="*", default=list(range(15, 19)), help="Layer indices to use for heatmap generation (default: 15-18)")
        concept_group.add_argument("--heatmap-timesteps", type=int, nargs="*", default=None, help="Timesteps to use for heatmap generation (default: all timesteps)")

    def add_metadata_config(self) -> None:
        self.supports_metadata_config = True
        # --config-from-metadata is the first released name (#703). It stays as an alias.
        self.add_argument("--config-from-conf", "--config-from-metadata", "-C", dest="config_from_metadata", type=Path, required=False, default=argparse.SUPPRESS, help="Use the parameters from a JSON sidecar that --make-conf wrote. Arguments that you give on the command line override the sidecar values.")

    def add_training_arguments(self) -> None:
        train_group = self.add_mutually_exclusive_group(required=True)
        train_group.add_argument(
            "--config",
            dest="config",
            type=Path,
            required=False,
            help="Local path of the training configuration file.",
        )
        train_group.add_argument(
            "--resume",
            dest="resume",
            type=Path,
            required=False,
            help="Path to a training checkpoint zip to resume.",
        )
        self.add_argument(
            "--dry-run",
            action="store_true",
            help="Validate training config/checkpoint and exit.",
        )

    def add_info_arguments(self) -> None:
        self.add_argument("image_path", type=str, help="Path to the image file to inspect")

    @staticmethod
    def _option_was_provided(*option_names: str) -> bool:
        argv = sys.argv[1:]
        for token in argv:
            if token in option_names:
                return True
            for option in option_names:
                if option.startswith("--") and token.startswith(f"{option}="):
                    return True
                if option.startswith("-") and not option.startswith("--") and len(option) == 2 and token.startswith(option) and token != option:
                    return True
        return False

    @staticmethod
    def warn_ignored_options(options_reasons: dict[str, str]) -> None:
        # One policy for options a model cannot honour: keep accepting them so existing
        # scripts do not break, but never drop them silently. Families that must
        # hard-error on a contradictory VALUE keep doing that themselves; this covers
        # the option-is-a-no-op case.
        for option, reason in options_reasons.items():
            if CommandLineParser._option_was_provided(option):
                warnings.warn(f"{option} is ignored; {reason}", stacklevel=2)

    def _normalize_atomic_lora_args(self, namespace: argparse.Namespace) -> None:
        if not self.supports_lora or not hasattr(namespace, "lora") or namespace.lora is None:
            return
        if self._option_was_provided("--lora-paths", "--lora-scales"):
            self.error("Use either --lora or the legacy --lora-paths/--lora-scales, not both.\nTip: --lora pairs each path with its scale: --lora A.safetensors 0.7 --lora B.safetensors 0.4")  # fmt: off
        paths: list[str] = []
        scales: list[float] = []
        for group in namespace.lora:
            if len(group) == 1:
                path, scale = group[0], 1.0
            elif len(group) == 2:
                path = group[0]
                try:
                    scale = float(group[1])
                except ValueError:
                    self.error(f"Invalid LoRA scale '{group[1]}' for '{group[0]}'.\nTip: --lora takes a PATH and an optional numeric SCALE: --lora {group[0]} 0.7")  # fmt: off
            else:
                self.error(f"--lora takes one PATH and an optional SCALE but got {len(group)} values: {' '.join(group)}\nTip: give each adapter its own --lora: --lora A.safetensors 0.7 --lora B.safetensors")  # fmt: off
            paths.append(path)
            scales.append(scale)
        namespace.lora_paths = paths
        namespace.lora_scales = scales

    def _normalize_atomic_image_args(self, namespace: argparse.Namespace) -> None:
        if not hasattr(namespace, "image") or namespace.image is None:
            return
        if self._option_was_provided("--image-path", "--image-strength"):
            self.error("Use either --image or the legacy --image-path/--image-strength, not both.\nTip: --image pairs the path with its strength: --image photo.jpg 0.6")  # fmt: off
        group = namespace.image
        if len(group) == 1:
            namespace.image_path = Path(group[0])
        elif len(group) == 2:
            namespace.image_path = Path(group[0])
            try:
                namespace.image_strength = float(group[1])
            except ValueError:
                self.error(f"Invalid image strength '{group[1]}' for '{group[0]}'.\nTip: --image takes a PATH and an optional numeric STRENGTH: --image {group[0]} 0.6")  # fmt: off
        else:
            self.error(f"--image takes one PATH and an optional STRENGTH but got {len(group)} values: {' '.join(group)}\nTip: --image photo.jpg 0.6")  # fmt: off

    def parse_args(self) -> argparse.Namespace:  # type: ignore
        namespace = super().parse_args()
        LoggingUtil.configure_logging(verbose=getattr(namespace, "verbose", False))

        if getattr(namespace, "no_metadata", False):
            from mflux.utils.image_util import ImageUtil

            ImageUtil.embed_metadata_enabled = False

        # Fold the atomic --lora / --image flags into the legacy lora_paths/lora_scales
        # and image_path/image_strength fields so all downstream logic (metadata merge,
        # path resolution, model init) stays unchanged. Runs before the metadata block.
        self._normalize_atomic_lora_args(namespace)
        self._normalize_atomic_image_args(namespace)

        # Check if either training arguments are provided
        has_training_args = (hasattr(namespace, "config") and namespace.config is not None) or \
                            (hasattr(namespace, "resume") and namespace.resume is not None)

        # Only enforce model requirement for path if we're not in training mode
        if hasattr(namespace, "path") and namespace.path is not None and namespace.model is None and not has_training_args:
            self.error("--model must be specified when using --path")

        lora_paths_from_metadata = False
        image_paths_from_metadata = False
        redux_image_paths_from_metadata = False

        if getattr(namespace, "config_from_metadata", False):
            prior_gen_metadata = json.load(namespace.config_from_metadata.open("rt"))

            restored_weights_source = None
            if hasattr(namespace, "model") and not self._option_was_provided("--model", "-m"):
                # When --model was not provided explicitly, metadata should win even if the
                # parser set a command-specific default model. A run whose weights came from
                # a path or third-party repo records that source in model_path, and the
                # source is what the command line actually said, so it wins over the
                # resolved registry entry in "model" (#705); older sidecars carry only the
                # entry and restore as before.
                restored_weights_source = prior_gen_metadata.get("model_path")
                namespace.model = restored_weights_source or prior_gen_metadata.get("model", namespace.model)

            if namespace.base_model is None:
                # Sidecars written before #695 store the literal string "None" for a builtin
                # run; it means the same as the null they store now, and handing it to the
                # --base-model validator below would reject the replay.
                restored_base_model = prior_gen_metadata.get("base_model", None)
                if restored_base_model in (None, "None") and restored_weights_source is not None:
                    # A restored weights source alone would erase the run's family: a
                    # restricted CLI of another family would pair the foreign weights with
                    # its default geometry instead of rejecting them the way it rejects the
                    # entry by name. The entry the run resolved to rides along as the
                    # explicit base, which keeps that rejection and pins the exact entry on
                    # the right CLI without re-inferring it from the basename.
                    restored_base_model = prior_gen_metadata.get("model", None)
                if restored_base_model not in (None, "None"):
                    namespace.base_model = restored_base_model

            if namespace.prompt is None:
                namespace.prompt = prior_gen_metadata.get("prompt", None)

            # Every run records the size it generated at and the negative prompt it used, but
            # neither was ever read back: a sidecar-only rerun regenerated at the 1024x1024
            # default (or at the init image's own size on the scale-factor CLIs) and with the
            # negative prompt dropped, which on a CFG model is a different image entirely.
            if hasattr(namespace, "negative_prompt") and not self._option_was_provided("--negative-prompt"):
                namespace.negative_prompt = prior_gen_metadata.get("negative_prompt") or namespace.negative_prompt
            if hasattr(namespace, "height") and not self._option_was_provided("--height"):
                namespace.height = prior_gen_metadata.get("height") or namespace.height
            if hasattr(namespace, "width") and not self._option_was_provided("--width"):
                namespace.width = prior_gen_metadata.get("width") or namespace.width
            for parameter in ("use_kv_cache", "output_resolution", "bake_lora"):
                option = parameter.replace("_", "-")
                if (
                    hasattr(namespace, parameter)
                    and parameter in prior_gen_metadata
                    and not self._option_was_provided(f"--{option}", f"--no-{option}")
                ):
                    if parameter == "bake_lora" and not isinstance(prior_gen_metadata[parameter], bool):
                        self.error(f"bake_lora in --config-from-conf: {prior_gen_metadata[parameter]!r} is not true or false.")  # fmt: off
                    setattr(namespace, parameter, prior_gen_metadata[parameter])
            # Step reuse changes the image, so a sidecar that recorded it replays it.
            if (
                hasattr(namespace, "step_cache_ratio")
                and prior_gen_metadata.get("step_cache_ratio") is not None
                and not self._option_was_provided("--step-cache-ratio", "--teacache-ratio")
            ):
                # Same range check as the flag, so a bad sidecar fails here instead of after the model loads.
                try:
                    namespace.step_cache_ratio = open_unit_float(str(prior_gen_metadata["step_cache_ratio"]))
                except argparse.ArgumentTypeError as exc:
                    self.error(f"step_cache_ratio in --config-from-conf: {exc}")
            # The steps --cfg-end runs without guidance change it too.
            if (
                hasattr(namespace, "cfg_end")
                and prior_gen_metadata.get("cfg_end") is not None
                and not self._option_was_provided("--cfg-end")
            ):
                # Same range check as the flag, so a bad sidecar fails here instead of after the model loads.
                try:
                    namespace.cfg_end = positive_fraction(str(prior_gen_metadata["cfg_end"]))
                except argparse.ArgumentTypeError as exc:
                    self.error(f"cfg_end in --config-from-conf: {exc}")
            # MOSS-Image records the layers its negative CFG branch skips. They change the image too.
            if (
                hasattr(namespace, "uncond_skip_layers")
                and prior_gen_metadata.get("uncond_skip_layers") is not None
                and not self._option_was_provided("--uncond-skip-layers")
            ):
                recorded_layers = prior_gen_metadata["uncond_skip_layers"]
                if not isinstance(recorded_layers, list) or not all(type(layer) is int for layer in recorded_layers):
                    self.error(f"uncond_skip_layers in --config-from-conf: {recorded_layers!r} is not a list of layer indices.")  # fmt: off
                namespace.uncond_skip_layers = recorded_layers
            # Float16 compute changes the image too, so a sidecar that recorded it replays it.
            if (
                hasattr(namespace, "compute_precision")
                and prior_gen_metadata.get("compute_precision") is not None
                and not self._option_was_provided("--compute-precision")
            ):
                # Same choices as the flag, so a bad sidecar fails here instead of after the model loads.
                recorded_precision = prior_gen_metadata["compute_precision"]
                if not isinstance(recorded_precision, str) or recorded_precision not in ComputePrecision.CHOICES:
                    self.error(f"compute_precision in --config-from-conf: invalid choice {recorded_precision!r} (choose from {', '.join(sorted(ComputePrecision.CHOICES))})")  # fmt: off
                namespace.compute_precision = recorded_precision
            # A schedule other than the default changes the image as well (Qwen-Image-2.1's viggle_turbo).
            if (
                hasattr(namespace, "scheduler")
                and prior_gen_metadata.get("scheduler") is not None
                and not self._option_was_provided("--scheduler")
            ):
                # Checked here so a bad sidecar fails before the model loads, and registered names only:
                # a dotted one would import whatever module the sidecar names.
                recorded_scheduler = prior_gen_metadata["scheduler"]
                if not isinstance(recorded_scheduler, str) or recorded_scheduler not in SCHEDULER_REGISTRY:
                    self.error(f"scheduler in --config-from-conf: {recorded_scheduler!r} is not a registered scheduler, and a sidecar doesn't import one. Pass --scheduler to use it.")  # fmt: off
                namespace.scheduler = recorded_scheduler

            # all configs from the metadata config defers to any explicitly defined args
            guidance_default = self.get_default("guidance")
            guidance_from_metadata = prior_gen_metadata.get("guidance")
            if namespace.guidance == guidance_default and guidance_from_metadata:
                namespace.guidance = guidance_from_metadata
            if namespace.quantize is None:
                namespace.quantize = prior_gen_metadata.get("quantize", None)
            seed_from_metadata = prior_gen_metadata.get("seed", None)
            if namespace.seed is None and seed_from_metadata is not None:
                namespace.seed = [seed_from_metadata]

            if namespace.seed is None:
                # not passed by user, not populated by metadata
                namespace.seed = [int(time.time())]

            if namespace.steps is None:
                namespace.steps = prior_gen_metadata.get("steps", None)

            if self.supports_lora:
                # LoRA defers to the command line like every other key here. It used to
                # concatenate instead, so no spelling could replace the sidecar's adapters —
                # and since only one of the two lists usually came from the CLI, the counts
                # disagreed and resolve_scales padded or truncated: `--lora-scales 0.8` on a
                # one-adapter sidecar generated at the sidecar's scale, not at 0.8.
                # --lora-paths with no values parses to [] and is the way to clear them.
                if not self._option_was_provided("--lora", "--lora-paths"):
                    namespace.lora_paths = prior_gen_metadata.get("lora_paths", None)
                    lora_paths_from_metadata = bool(namespace.lora_paths)
                    # Scales are their own axis: alone they re-run the sidecar's adapters at a
                    # different strength, but they never outlive a CLI-supplied path list.
                    if not self._option_was_provided("--lora-scales"):
                        namespace.lora_scales = prior_gen_metadata.get("lora_scales", None)

            if hasattr(namespace, "image_path") and namespace.image_path is None:
                namespace.image_path = prior_gen_metadata.get("image_path", None)

            if hasattr(namespace, "image_paths") and namespace.image_paths is None:
                namespace.image_paths = [Path(p) for p in prior_gen_metadata.get("image_paths") or []] or None
                image_paths_from_metadata = namespace.image_paths is not None

            if hasattr(namespace, "redux_image_paths") and namespace.redux_image_paths is None:
                # Only a JSON list is restorable. Older sidecars wrote str(list) (a Python
                # repr) and that string is not a path list — leave it unset so the post-parse
                # requirement names --redux-image-paths instead of iterating characters.
                raw_redux_paths = prior_gen_metadata.get("redux_image_paths")
                if isinstance(raw_redux_paths, list):
                    namespace.redux_image_paths = [Path(p) for p in raw_redux_paths] or None
                    redux_image_paths_from_metadata = namespace.redux_image_paths is not None
                if (
                    namespace.redux_image_strengths is None
                    and not self._option_was_provided("--redux-image-strengths")
                    and (redux_strengths := prior_gen_metadata.get("redux_image_strengths"))
                ):
                    namespace.redux_image_strengths = redux_strengths

            if hasattr(namespace, "mask_path") and namespace.mask_path is None:
                namespace.mask_path = (
                    prior_gen_metadata.get("masked_image_path", None) or prior_gen_metadata.get("mask_path", None)
                )

            if self.supports_image_to_image:
                if namespace.image_strength == self.get_default("image_strength") and (img_strength_from_metadata := prior_gen_metadata.get("image_strength", None)):
                    namespace.image_strength = img_strength_from_metadata

            if self.supports_controlnet:
                if namespace.controlnet_image_path is None:
                    namespace.controlnet_image_path = prior_gen_metadata.get("controlnet_image_path", None)
                if namespace.controlnet_strength == self.get_default("controlnet_strength") and (cnet_strength_from_metadata := prior_gen_metadata.get("controlnet_strength", None)):
                    namespace.controlnet_strength = cnet_strength_from_metadata

            if hasattr(namespace, "float32") and not self._option_was_provided("--float32", "--no-float32"):
                namespace.float32 = bool(prior_gen_metadata.get("float32", False))

            if hasattr(namespace, "small_text_encoder") and not self._option_was_provided("--small-text-encoder", "--no-small-text-encoder"):  # fmt: skip
                # A JSON boolean only: bool("false") is True, and the small encoder changes the image.
                recorded_small_text_encoder = prior_gen_metadata.get("small_text_encoder")
                recorded_small_text_encoder = False if recorded_small_text_encoder is None else recorded_small_text_encoder
                if not isinstance(recorded_small_text_encoder, bool):
                    self.error(f"small_text_encoder in --config-from-metadata must be true or false, not {recorded_small_text_encoder!r}.")  # fmt: off
                namespace.small_text_encoder = recorded_small_text_encoder

            if hasattr(namespace, "pid_decode") and not self._option_was_provided("--pid-decode", "--no-pid-decode"):
                namespace.pid_decode = prior_gen_metadata.get("pid_decode", False)

            if hasattr(namespace, "small_decoder") and not self._option_was_provided("--small-decoder", "--no-small-decoder"):
                # A JSON boolean only: bool("false") is True, and a wrong decoder changes the image.
                recorded_small_decoder = prior_gen_metadata.get("small_decoder")
                recorded_small_decoder = False if recorded_small_decoder is None else recorded_small_decoder
                if not isinstance(recorded_small_decoder, bool):
                    self.error(f"small_decoder in --config-from-metadata must be true or false, not {recorded_small_decoder!r}.")  # fmt: off
                namespace.small_decoder = recorded_small_decoder

            if hasattr(namespace, "vae_full_precision") and not self._option_was_provided("--vae-full-precision", "--no-vae-full-precision"):  # fmt: skip
                # A JSON boolean only: bool("false") is True, and the decode mode changes the image.
                recorded_vae_full_precision = prior_gen_metadata.get("vae_full_precision")
                recorded_vae_full_precision = False if recorded_vae_full_precision is None else recorded_vae_full_precision
                if not isinstance(recorded_vae_full_precision, bool):
                    self.error(f"vae_full_precision in --config-from-metadata must be true or false, not {recorded_vae_full_precision!r}.")  # fmt: off
                namespace.vae_full_precision = recorded_vae_full_precision

            if hasattr(namespace, "render_text_images") and not self._option_was_provided("--text-images", "--no-text-images"):  # fmt: skip
                # FIBO 2 records its text images only when they are off. A JSON boolean only, as above.
                recorded_text_images = prior_gen_metadata.get("render_text_images")
                recorded_text_images = True if recorded_text_images is None else recorded_text_images
                if not isinstance(recorded_text_images, bool):
                    self.error(f"render_text_images in --config-from-metadata must be true or false, not {recorded_text_images!r}.")  # fmt: off
                namespace.render_text_images = recorded_text_images

            if hasattr(namespace, "pid_degrade_sigma") and not self._option_was_provided("--pid-degrade-sigma"):
                # Non-PiD sidecars omit the key entirely, but a hand-edited one can carry an
                # explicit null, which `.get(..., 0.0)` returns as-is. Normalize it, or
                # `--config-from-metadata <such a sidecar> --pid-decode` hands None to the
                # decoder's float-only sigma range check.
                metadata_sigma = prior_gen_metadata.get("pid_degrade_sigma")
                namespace.pid_degrade_sigma = 0.0 if metadata_sigma is None else metadata_sigma

        # Only require model if we're not in training mode and require_model_arg is True
        if hasattr(namespace, "model") and namespace.model is None and not has_training_args and self.require_model_arg:
            self.error("--model / -m must be provided, or 'model' must be specified in the config file.")

        if self.require_init_image and getattr(namespace, "image_path", None) is None:
            self.error("An init image is required. Provide one with --image PATH [STRENGTH] (e.g. --image photo.jpg 0.8).")

        if self.require_image_paths and not getattr(namespace, "image_paths", None):
            self.error("At least one init image is required. Provide one with --image-paths PATH [PATH ...] (e.g. --image-paths photo.jpg).")

        if self.require_redux_image_paths and not getattr(namespace, "redux_image_paths", None):
            self.error("At least one redux image is required. Provide one with --redux-image-paths PATH [PATH ...] (e.g. --redux-image-paths photo.jpg).")

        if image_paths_from_metadata and (missing := [path for path in namespace.image_paths if not path.exists()]):
            # A sidecar records the resolved absolute path, so one carried between machines
            # fails on an argument the user never typed — and, without this, only after the
            # model has loaded, since nothing opens the file until dimension resolution.
            self.error(f"Init image not found: {', '.join(str(path) for path in missing)}\nTip: that path came from {namespace.config_from_metadata}. Pass --image-paths PATH [PATH ...] to use your own copy.")  # fmt: off

        if redux_image_paths_from_metadata and (missing := [path for path in namespace.redux_image_paths if not path.exists()]):
            self.error(f"Redux image not found: {', '.join(str(path) for path in missing)}\nTip: that path came from {namespace.config_from_metadata}. Pass --redux-image-paths PATH [PATH ...] to use your own copy.")  # fmt: off

        if self.supports_image_generation and namespace.seed is None and namespace.auto_seeds > 0:
            # choose N unique int seeds in the range of  0 < value < 1 billion
            # Use random.sample to guarantee uniqueness
            max_seed_value = int(1e7)
            if namespace.auto_seeds > max_seed_value + 1:
                # If requesting more seeds than possible unique values, allow duplicates
                namespace.seed = [random.randint(0, max_seed_value) for _ in range(namespace.auto_seeds)]
            else:
                namespace.seed = random.sample(range(max_seed_value + 1), namespace.auto_seeds)

        if self.supports_image_generation and namespace.seed is None:
            # final default: did not obtain seed from metadata, --seed, or --auto-seeds
            namespace.seed = [int(time.time())]

        if self.supports_image_generation and len(namespace.seed) > 1:
            # auto append seed-$value to output names for multi image generations
            # e.g. output.png -> output_seed_101.png output_seed_102.png, etc
            output_path = Path(namespace.output)
            namespace.output = str(output_path.with_stem(output_path.stem + "_seed_{seed}"))

        if hasattr(namespace, "image_path") and isinstance(namespace.image_path, list) and len(namespace.image_path) > 1:
            # auto append image-$name to output names for multi image generations
            output_path = Path(namespace.output)
            namespace.output = str(output_path.with_stem(output_path.stem + "_{image_name}"))

        if self.supports_image_generation and getattr(namespace, "prompt", None) is None and getattr(namespace, "prompt_file", None) is None:
            # when metadata config is supported but neither prompt nor prompt-file is provided
            # Only error if prompt is actually required
            if getattr(self, 'require_prompt', True):
                self.error("Either --prompt or --prompt-file argument is required, or 'prompt' required in metadata config file")

        if self.supports_image_generation and getattr(namespace, "steps", None) is None:
            # The chain is explicit flag -> the checkpoint's own name -> the CLI's default
            # model -> the generic 25. Most single-model CLIs resolve --model in main(), so
            # namespace.model is still None here; passing default_model as the FALLBACK
            # rather than substituting it for model_name keeps --base-model's promotion
            # alive (`--base-model flux2-klein-base-9b` with no --model runs the 50-step
            # base, not the default entry's 4), and gives a custom checkpoint with no
            # usable name the count of the entry the restricted CLIs actually run it on.
            namespace.steps = ui_defaults.model_inference_steps(
                getattr(namespace, "model", None),
                getattr(namespace, "base_model", None),
                fallback_model=self.default_model,
            )

        # In-context edit: exclusivity lives in the argparse group; only the
        # "at least one" half needs a post-parse check.
        if getattr(self, 'supports_in_context_edit', False):
            if not getattr(namespace, 'prompt', None) and not getattr(namespace, 'instruction', None):
                self.error("Either --prompt or --instruction argument is required for in-context editing")

        if self.supports_image_outpaint and namespace.image_outpaint_padding is not None:
            # parse and normalize any acceptable 1,2,3,4-tuple box value to 4-tuple
            namespace.image_outpaint_padding = box_values.BoxValues.parse(namespace.image_outpaint_padding)

        # Resolve lora paths from library if needed
        if self.supports_lora and hasattr(namespace, "lora_paths") and namespace.lora_paths:
            resolved_paths = []
            for lora_path in namespace.lora_paths:
                try:
                    resolved_path = LoraResolution.resolve(lora_path)
                    resolved_paths.append(resolved_path)
                except (FileNotFoundError, ValueError) as e:  # noqa: PERF203
                    # A sidecar records the adapter's resolved absolute path, so one carried
                    # between machines fails on an argument the user never typed. Say where it
                    # came from, or the message reads as a typo in a flag that is not there.
                    tip = f"\nTip: that path came from {namespace.config_from_metadata}. Pass --lora PATH [SCALE] to use your own copy, or --lora-paths with no values to run without it." if lora_paths_from_metadata else ""  # fmt: off
                    self.error(f"{e}{tip}")
            namespace.lora_paths = resolved_paths

        # Validate --base-model against the resolver's own list rather than a static
        # choices=, and do it here so a value restored from a metadata sidecar is held to
        # the same rule as one typed on the command line.
        if getattr(namespace, "base_model", None) is not None:
            if namespace.base_model not in ConfigResolution.base_model_names():
                self.error(
                    f"argument --base-model: invalid choice: {namespace.base_model!r} "
                    f"(choose from {', '.join(ConfigResolution.base_model_keys())}, "
                    f"any of their aliases, or the HuggingFace repo id of a built-in model)"
                )

        # Compute model_path: None for built-in model names, otherwise use the model value
        # Names known to the registry (any canonical key or alias) are handled by
        # ModelConfig; anything else is a HuggingFace repo id or a local checkpoint path.
        if hasattr(namespace, "model") and namespace.model is not None:
            namespace.model_path = None if namespace.model in ui_defaults.model_choices() else namespace.model
        else:
            namespace.model_path = None

        # Hand the weights source to the sidecar writer (#705). GeneratedImage cannot see
        # the namespace, so this travels the way --no-exif reaches ImageUtil; set on
        # every parse so one run's path cannot leak into the next.
        from mflux.utils.generated_image import GeneratedImage

        GeneratedImage.model_path = namespace.model_path

        return namespace
