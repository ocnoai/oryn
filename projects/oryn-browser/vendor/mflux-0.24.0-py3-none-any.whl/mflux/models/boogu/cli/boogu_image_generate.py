from argparse import Namespace

from mflux.callbacks.callback_manager import CallbackManager
from mflux.cli.parser.parsers import CommandLineParser
from mflux.models.boogu.variants import BooguImage
from mflux.models.common.config.model_config import ModelConfig
from mflux.models.common.resolution.config_resolution import ConfigResolution
from mflux.utils.exceptions import PromptFileReadError, StopImageGenerationException
from mflux.utils.generated_image import GeneratedImage
from mflux.utils.prompt_util import PromptUtil

# The model this CLI runs when --model is omitted. The parser needs it too, to key the
# --steps default off the right model instead of falling back to FLUX.1-dev's 25.
DEFAULT_MODEL = "boogu-image-turbo"

# Single source of truth for options this CLI accepts but cannot honour: the runtime
# warning and the mflux-capabilities dump both read it.
IGNORED_OPTIONS = {
    "--guidance": "Boogu Image Turbo is guidance-distilled; CFG is disabled.",
    "--negative-prompt": "CFG is disabled on Boogu Image Turbo, so the negative prompt is never encoded.",
}


def build_parser() -> CommandLineParser:
    parser = CommandLineParser(
        description="Generate an image using Boogu-Image-Turbo (4-step DMD). "
        "Tip: 4 steps is enough up to ~768px; use --steps 8 at 1024x1024, where 4 steps under-resolves detail."
    )
    parser.add_general_arguments()
    parser.add_model_arguments(require_model_arg=False, default_model=DEFAULT_MODEL)
    # No add_lora_arguments(): mflux has no LoRA mapping for Boogu, and accepting the
    # flags meant resolving and downloading the adapter before dropping it silently.
    # Same shape as mflux-generate-lens, which has never taken them.
    parser.add_image_generator_arguments(supports_metadata_config=True)
    parser.add_output_arguments()
    return parser


class BooguImageCommand:
    # Boogu builds its own noise latents (no LatentCreator); stepwise output is unsupported.
    latent_creator = None

    @staticmethod
    def validate(args: Namespace) -> ModelConfig:
        # Weight-free: resolves --model against the in-memory registry only.
        return ConfigResolution.resolve_restricted(args.model, DEFAULT_MODEL, model_path=args.model_path)

    @staticmethod
    def load(args: Namespace) -> BooguImage:
        return BooguImage(
            model_config=BooguImageCommand.validate(args),
            quantize=args.quantize,
            model_path=args.model_path,
        )

    @staticmethod
    def generate(model: BooguImage, args: Namespace, seed: int, prompt: str) -> GeneratedImage:
        # The parser takes plain ints for sizes here, so they go to the model unchanged.
        return model.generate_image(
            seed=seed,
            prompt=prompt,
            width=args.width,
            height=args.height,
            num_inference_steps=args.steps,
        )


def main():
    # 0. Parse command line arguments
    parser = build_parser()
    args = parser.parse_args()
    CommandLineParser.warn_ignored_options(IGNORED_OPTIONS)

    model = BooguImageCommand.load(args)

    memory_saver = CallbackManager.register_callbacks(
        args=args,
        model=model,
        latent_creator=BooguImageCommand.latent_creator,
    )

    try:
        for seed in args.seed:
            image = BooguImageCommand.generate(model, args, seed, PromptUtil.read_prompt(args))
            image.save(path=args.output.format(seed=seed), export_json_metadata=args.metadata)
    except (StopImageGenerationException, PromptFileReadError) as exc:
        print(exc)
    finally:
        if memory_saver:
            print(memory_saver.memory_stats())


if __name__ == "__main__":
    main()
