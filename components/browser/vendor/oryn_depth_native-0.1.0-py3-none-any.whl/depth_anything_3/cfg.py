"""The Oryn native subset accepts engine-constructed modules only."""

def create_object(*args, **kwargs):
    raise ValueError("DEPTH_NATIVE_DYNAMIC_CONSTRUCTION_DISABLED")
